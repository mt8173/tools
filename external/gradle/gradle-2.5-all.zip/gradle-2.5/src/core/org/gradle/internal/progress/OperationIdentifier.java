/*
 * Copyright 2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.gradle.internal.progress;

import java.io.Serializable;

public class OperationIdentifier implements Serializable {
    private final long id;
    private final Long parentId;

    public OperationIdentifier(long id, Long parentId) {
        this.id = id;
        this.parentId = parentId;
    }

    public long getId() {
        return id;
    }

    public Long getParentId() {
        return parentId;
    }

    @Override
    public String toString() {
        return id + ":" + parentId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        OperationIdentifier that = (OperationIdentifier) o;

        if (getId() != that.getId()) {
            return false;
        }
        return !(getParentId() != null ? !getParentId().equals(that.getParentId()) : that.getParentId() != null);

    }

    @Override
    public int hashCode() {
        int result = (int) (getId() ^ (getId() >>> 32));
        result = 31 * result + (getParentId() != null ? getParentId().hashCode() : 0);
        return result;
    }
}
